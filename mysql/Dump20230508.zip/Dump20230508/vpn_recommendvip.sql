-- MySQL dump 10.13  Distrib 8.0.25, for macos11 (x86_64)
--
-- Host: 140.99.221.95    Database: vpn
-- ------------------------------------------------------
-- Server version	5.6.40-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `recommendvip`
--

DROP TABLE IF EXISTS `recommendvip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recommendvip` (
  `id` int(11) NOT NULL,
  `title` varchar(45) COLLATE utf8_bin NOT NULL,
  `actionUrl` varchar(100) COLLATE utf8_bin NOT NULL,
  `img` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `desc` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `enable` int(11) DEFAULT '1',
  `color` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `rate` float DEFAULT '1',
  `imgPath` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `type` int(11) DEFAULT '0',
  `adsShow` int(11) DEFAULT '0',
  `adsPopShow` int(11) DEFAULT '0',
  `showType` int(11) DEFAULT '0',
  `minVersion` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `newShow` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recommendvip`
--

LOCK TABLES `recommendvip` WRITE;
/*!40000 ALTER TABLE `recommendvip` DISABLE KEYS */;
INSERT INTO `recommendvip` VALUES (59,'How To VIP','http://file.sspacee.com/file/html/about.html?1',NULL,NULL,1,1,NULL,0.7,'http://img.sspacee.com/file/recommend/',0,0,0,2,'001000002002',0),(62,'文字小说','text://config?channel=bbb996','zc2.jpg',NULL,1,1,'#e3c295',1,'http://img.sspacee.com/file/recommend/',0,1,1,1,'001000002007',1),(64,'养眼图片','img://config?channel=meitu_sex','seximg.jpg',NULL,1,1,'#662d5d82',1.5,'http://img.sspacee.com/file/recommend/',0,1,1,1,'001000002008',1),(71,'Playboy','http://www.playboy.com/','playboy.jpg',NULL,1,1,'#d6c2b7',1.3,'http://img.sspacee.com/file/recommend/',1,0,0,0,'001000002002',1),(81,'墙外楼','browser://config?url=http%3a%2f%2fm.letscorp.net/',NULL,NULL,1,1,'#887267',1,NULL,0,0,0,0,'001000003006',1),(82,'搞笑GIF','img://config?channel=gaoxiao_gif',NULL,NULL,1,1,'#887267',1,NULL,1,0,0,0,'001000003006',1);
/*!40000 ALTER TABLE `recommendvip` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-08 13:30:03
