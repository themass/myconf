-- MySQL dump 10.13  Distrib 8.0.25, for macos11 (x86_64)
--
-- Host: 140.99.221.95    Database: vpn
-- ------------------------------------------------------
-- Server version	5.6.40-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `version`
--

DROP TABLE IF EXISTS `version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `version` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(45) COLLATE utf8_bin NOT NULL,
  `platform` varchar(45) COLLATE utf8_bin NOT NULL,
  `content` varchar(200) COLLATE utf8_bin NOT NULL,
  `time` datetime DEFAULT NULL,
  `url` varchar(100) COLLATE utf8_bin NOT NULL,
  `minBuild` varchar(45) COLLATE utf8_bin NOT NULL,
  `maxBuild` varchar(45) COLLATE utf8_bin NOT NULL,
  `channel` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `showGdt` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `version`
--

LOCK TABLES `version` WRITE;
/*!40000 ALTER TABLE `version` DISABLE KEYS */;
INSERT INTO `version` VALUES (12,'1.1.8.17','android','* 修复流量达到上限异常\n* 修复广告积分异常\n','2018-01-01 11:11:11','http://file.sspacee.com/file/app/FreeV9N_11817.apk','1000001000','1000008008','VVVB_VVV',0),(21,'1.1.8.17','android','* 修复流量达到上限异常\n* 修复广告积分异常','2018-05-28 11:11:11','http://file.sspacee.com/file/app/FreeV9N_11817.apk','1000008008','1000008008','VVV',0),(22,'1.1.8.17','android','* 修复流量达到上限异常\n* 修复广告积分异常','2018-08-05 00:00:00','http://file.sspacee.com/file/app/FreeV9N_11817.apk','1000008008','1000008008','MYPOOL_VVV',0),(23,'1.1.8.11','android','* 修复流量达到上限异常\n* 修复广告积分异常','2018-08-05 00:00:00','http://file.sspacee.com/file/app/FreeV9N_11817.apk','1000008008','1000008008','MYPOOL_SEX',1),(24,'1.1.8.17','android','* 修复流量达到上限异常\n* 修复广告积分异常','2018-05-28 11:11:11','http://file.sspacee.com/file/app/FreeV9N_11817.apk','1000008008','1000008008','NETTYPEA_VVV',0),(25,'1.0.8.22','android','* 修复流量达到上限异常\n* 修复广告积分异常','2018-05-28 11:11:11','http://file.sspacee.com/file/app/FreeV9N_11817.apk','1000001000','1000008024','VVVC_VVV',0),(26,'1.1.8.11','android','* 修复流量达到上限异常\n* 修复广告积分异常','2018-05-28 11:11:11','http://file.sspacee.com/file/app/FreeV9N_11817.apk','1000008000','1000008000','SEX',1),(27,'1.1.8.11','android','* 修复流量达到上限异常\n* 修复广告积分异常','2018-05-28 11:11:11','http://file.sspacee.com/file/app/FreeV9N_11817.apk','1000008000','1000008000','SEX_TEMP',1),(28,'1.0.1.0','android','* 修复流量达到上限异常\n* 修复广告积分异常','2018-05-28 11:11:11','http://file.sspacee.com/file/app/FreeV9N_11817.apk','1000001000','1000001000','VVVD_VVV',0),(29,'1.1.8.11','android','* 修复流量达到上限异常\n* 修复广告积分异常','2018-05-28 11:11:11','http://file.sspacee.com/file/app/FreeV9N_11817.apk','1000001000','1000001000','SEXPLAY_SEX',1);
/*!40000 ALTER TABLE `version` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-08 13:31:25
