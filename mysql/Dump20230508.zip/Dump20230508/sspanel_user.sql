-- MySQL dump 10.13  Distrib 8.0.25, for macos11 (x86_64)
--
-- Host: 140.99.221.95    Database: sspanel
-- ------------------------------------------------------
-- Server version	5.6.40-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `due_date` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `transfer_enable` bigint(20) NOT NULL DEFAULT '0',
  `port` int(11) NOT NULL DEFAULT '0',
  `email` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `pass` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `passwd` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `t` int(11) NOT NULL DEFAULT '0',
  `u` bigint(20) NOT NULL DEFAULT '0',
  `d` bigint(20) NOT NULL DEFAULT '0',
  `switch` tinyint(4) NOT NULL DEFAULT '1',
  `enable` tinyint(4) NOT NULL DEFAULT '1',
  `type` tinyint(4) NOT NULL DEFAULT '1',
  `last_get_gift_time` int(11) NOT NULL DEFAULT '0',
  `last_check_in_time` int(11) NOT NULL DEFAULT '0',
  `last_rest_pass_time` int(11) NOT NULL DEFAULT '0',
  `reg_date` timestamp NOT NULL DEFAULT '1989-06-03 18:10:29',
  `invite_num` int(11) NOT NULL DEFAULT '0',
  `is_admin` int(11) NOT NULL DEFAULT '0',
  `ref_by` int(11) NOT NULL DEFAULT '0',
  `expire_time` int(11) NOT NULL DEFAULT '0',
  `method` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'rc4-md5',
  `custom_method` tinyint(4) NOT NULL DEFAULT '0',
  `custom_rss` tinyint(4) NOT NULL DEFAULT '0',
  `protocol` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'origin',
  `protocol_param` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `obfs` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'plain',
  `obfs_param` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_email_verify` tinyint(4) NOT NULL DEFAULT '0',
  `reg_ip` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '127.0.0.1',
  `v2ray_uuid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `v2ray_level` int(11) NOT NULL DEFAULT '2',
  `v2ray_alter_id` int(11) NOT NULL DEFAULT '2',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `port` (`port`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','2020年01月12日',307374182400,1025,'themass@163.com','$2y$10$l7mcdegFfp/ngwCxXXR86.19aQzvDZ7vn5DDeedq6M1Rcy0Hx214O','kyC08a',1683287902,1341024866,8271624988,1,1,1,0,0,0,'1989-06-03 18:10:29',0,1,0,0,'rc4-md5',0,0,'origin','','plain','',0,'127.0.0.1','',2,2),(4,'test',NULL,0,1026,'test@163.com','$2y$10$vhagxCwtV5d3IfuW8dsBROFxYWxtKMQLB35cfBGTSj0AiwGsNeMxG','H7CWLJ',1544777193,0,0,1,1,1,0,0,0,'1989-06-03 18:10:29',0,0,2,0,'rc4-md5',0,0,'origin','','plain','',0,'183.84.14.254','ba22bf41-e8c2-445e-8166-40349b3f2fb6',2,2);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-08 13:49:17
