-- MySQL dump 10.13  Distrib 8.0.25, for macos11 (x86_64)
--
-- Host: 140.99.221.95    Database: vpn
-- ------------------------------------------------------
-- Server version	5.6.40-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `recommendvip_sex`
--

DROP TABLE IF EXISTS `recommendvip_sex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recommendvip_sex` (
  `id` int(11) NOT NULL,
  `title` varchar(45) COLLATE utf8_bin NOT NULL,
  `actionUrl` varchar(100) COLLATE utf8_bin NOT NULL,
  `img` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `desc` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `enable` int(11) DEFAULT '1',
  `color` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `rate` float DEFAULT '1',
  `imgPath` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `type` int(11) DEFAULT '0',
  `adsShow` int(11) DEFAULT '0',
  `adsPopShow` int(11) DEFAULT '0',
  `showType` int(11) DEFAULT '0',
  `minVersion` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `newShow` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recommendvip_sex`
--

LOCK TABLES `recommendvip_sex` WRITE;
/*!40000 ALTER TABLE `recommendvip_sex` DISABLE KEYS */;
INSERT INTO `recommendvip_sex` VALUES (1,'jiu667','video://config?channel=jiu667_all',NULL,NULL,1,1,'#e3c295',1.2,NULL,0,0,0,1,'000000002002',1),(2,'testlist','videoList://config?channel=testlist',NULL,NULL,1,1,'#e3c295',1.2,NULL,0,0,0,1,'000000002002',1),(3,'user','video://config?channel=users',NULL,NULL,1,1,'#e3c295',1.2,NULL,0,0,0,1,'000000002002',1),(4,'hsex.men','video://config?channel=hsex_all',NULL,NULL,1,1,'#e3c295',1.2,NULL,0,0,0,1,'000000002002',1),(5,'xx69','video://config?channel=69xx_all',NULL,NULL,1,1,'#e3c295',1.2,NULL,0,0,0,1,'000000002002',0),(6,'nuyou','video://config?channel=nvyou',NULL,NULL,1,1,'#e3c295',1.2,NULL,0,0,0,1,'000000002002',1),(7,'好听的音乐','sound://config?channel=nvyou',NULL,NULL,1,1,'#e3c295',1.2,NULL,0,0,0,1,'000000002002',0),(8,'好看的图片','img://config?channel=porn_sex',NULL,NULL,1,1,'#e3c295',1.2,NULL,0,0,0,0,'000000002002',0),(9,'test','video://config?channel=test',NULL,NULL,1,1,'#e3c295',1.2,NULL,0,0,0,1,'000000002002',1),(10,'好看的动漫','video://config?channel=hanime_all',NULL,NULL,1,1,'#e3c295',1.2,NULL,0,0,0,1,NULL,1);
/*!40000 ALTER TABLE `recommendvip_sex` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-08 13:48:13
