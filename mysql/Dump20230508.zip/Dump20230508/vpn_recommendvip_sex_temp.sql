-- MySQL dump 10.13  Distrib 8.0.25, for macos11 (x86_64)
--
-- Host: 140.99.221.95    Database: vpn
-- ------------------------------------------------------
-- Server version	5.6.40-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `recommendvip_sex_temp`
--

DROP TABLE IF EXISTS `recommendvip_sex_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recommendvip_sex_temp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(45) COLLATE utf8_bin NOT NULL,
  `actionUrl` varchar(100) COLLATE utf8_bin NOT NULL,
  `img` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `desc` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `sort` int(11) DEFAULT '1',
  `enable` int(11) DEFAULT '1',
  `color` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `rate` float DEFAULT '1',
  `imgPath` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `type` int(11) DEFAULT '0',
  `adsShow` int(11) DEFAULT '0',
  `adsPopShow` int(11) DEFAULT '0',
  `showType` int(11) DEFAULT '0',
  `minVersion` varchar(45) COLLATE utf8_bin DEFAULT '0',
  `newShow` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recommendvip_sex_temp`
--

LOCK TABLES `recommendvip_sex_temp` WRITE;
/*!40000 ALTER TABLE `recommendvip_sex_temp` DISABLE KEYS */;
INSERT INTO `recommendvip_sex_temp` VALUES (1,'腾讯视频','https://v.qq.com/','qq.png',NULL,1,1,NULL,1,'http://img.sspacee.com/file/recommend/',0,0,0,0,'0',0),(2,'爱奇艺','http://www.iqiyi.com/','iqi.png',NULL,1,1,NULL,1,'http://img.sspacee.com/file/recommend/',0,0,0,0,'0',0),(84,'优酷','http://www.youku.com/','youku.png',NULL,1,1,NULL,1,'http://img.sspacee.com/file/recommend/',0,0,0,0,'0',0),(85,'百度视频','http://v.baidu.com/','baidu.png',NULL,1,1,NULL,1,'http://img.sspacee.com/file/recommend/',0,0,0,0,'0',0),(86,'哔哩哔哩','https://www.bilibili.com/','bili.png',NULL,1,1,NULL,1,'http://img.sspacee.com/file/recommend/',0,0,0,0,'0',0),(87,'搜狐视频','https://tv.sohu.com/','souhu.png',NULL,1,1,NULL,1,'http://img.sspacee.com/file/recommend/',0,0,0,0,'0',0),(88,'芒果tv','https://www.mgtv.com/','mgtv.png',NULL,1,1,NULL,1,'http://img.sspacee.com/file/recommend/',0,0,0,0,'0',0),(89,'pptv','http://www.pptv.com/','pptv.png',NULL,1,1,NULL,1,'http://img.sspacee.com/file/recommend/',0,0,0,0,'0',0),(90,'y3600','https://www.y3600.com/','y3600.png',NULL,1,1,NULL,1,'http://img.sspacee.com/file/recommend/',0,0,0,0,'0',0),(91,'大土豆','http://new-www.tudou.com/?','td.png',NULL,1,1,NULL,1,'http://img.sspacee.com/file/recommend/',0,0,0,0,'0',0),(92,'六间房','https://www.6.cn/?mks=cpcbaidu&mkk=%E5%85%AD%E9%97%B4%E6%88%BF&mkc=g0007','6jf.png',NULL,1,1,NULL,1,'http://img.sspacee.com/file/recommend/',0,0,0,0,'0',0),(93,'NetFlix','https://www.netflix.com/hk-en/',NULL,NULL,1,1,NULL,1,'http://img.sspacee.com/file/recommend/',0,0,0,0,'0',0),(94,'Yahoo! Screen','https://tw.tv.yahoo.com/',NULL,NULL,1,1,NULL,1,'http://img.sspacee.com/file/recommend/',0,0,0,0,'0',0),(95,'Vimeo','https://vimeo.com/',NULL,NULL,1,1,NULL,1,'http://img.sspacee.com/file/recommend/',0,0,0,0,'0',0),(96,'Vube','http://vube.com/',NULL,NULL,1,1,NULL,1,'http://img.sspacee.com/file/recommend/',0,0,0,0,'0',0),(97,'LiveLeak','https://www.liveleak.com/',NULL,NULL,1,1,NULL,1,'http://img.sspacee.com/file/recommend/',0,0,0,0,'0',0),(98,'DailyMotion','http://www.dailymotion.com/',NULL,NULL,1,1,NULL,1,'http://img.sspacee.com/file/recommend/',0,0,0,0,'0',0),(99,'MetaCafe','http://www.metacafe.com/',NULL,NULL,1,1,NULL,1,'http://img.sspacee.com/file/recommend/',0,0,0,0,'0',0),(100,'MySpace Videos','https://myspace.com/discover/videos',NULL,NULL,1,1,NULL,1,'http://img.sspacee.com/file/recommend/',0,0,0,0,'0',0),(101,'TV','https://www.tvguide.com/',NULL,NULL,1,1,NULL,1,'http://img.sspacee.com/file/recommend/',0,0,0,0,'0',0),(102,'美拍','http://www.meipai.com/','meipai.png',NULL,1,1,NULL,1,'http://img.sspacee.com/file/recommend/',0,0,0,0,'0',0),(103,'Mevio','http://www.mevio.com/ ',NULL,NULL,1,1,NULL,1,'http://img.sspacee.com/file/recommend/',0,0,0,0,'0',0);
/*!40000 ALTER TABLE `recommendvip_sex_temp` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-08 13:47:43
