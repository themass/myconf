-- MySQL dump 10.13  Distrib 8.0.25, for macos11 (x86_64)
--
-- Host: 140.99.221.95    Database: vpn
-- ------------------------------------------------------
-- Server version	5.6.40-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `imgchannel`
--

DROP TABLE IF EXISTS `imgchannel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imgchannel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `url` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `baseurl` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `pic` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  `updateTime` datetime DEFAULT NULL,
  `rate` float DEFAULT '1.1',
  `showType` int(11) DEFAULT '1',
  `enable` int(11) NOT NULL DEFAULT '1',
  `channel` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index3` (`url`),
  KEY `index4` (`channel`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=12382 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imgchannel`
--

LOCK TABLES `imgchannel` WRITE;
/*!40000 ALTER TABLE `imgchannel` DISABLE KEYS */;
INSERT INTO `imgchannel` VALUES (12374,'偷窥自拍','/toukuizipai/index.html','http://667jiu.com','https://www.y21j45k89b66.com/160C02/p01/%E4%B8%80%E5%B0%8D%E5%B0%8F%E6%83%85%E4%BE%B6%E5%9C%A8%E5%AE%B6%E7%82%BA%E5%A5%B3%E5%8F%8B%E6%8B%8D%E5%AF%AB%E7%9C%9F%EF%BC%8C%E5%A5%B3%E5%8F%8B%E5%B0%8D%E8%91%97%E9%9B%BB%E8%85%A6%E4%B8%8A%E7%9A%84%E5%9C%96%E9','2023-03-06 22:14:03',1.2,3,1,'porn_sex',0),(12375,'亚洲色图','/yazhousetu/index.html','http://667jiu.com','https://www.y21j45k89b66.com/160C02/p02/%E4%B9%B1%E6%84%9F%E6%9F%93%E7%97%85%E6%A3%9F%20%E7%AC%AC%E4%BA%8C%E7%AB%A0%20%E5%90%89%E6%B2%A2%E6%98%8E%E6%AD%A9%20%5B10P%5D/01.jpg','2023-03-06 22:14:03',1.2,3,1,'porn_sex',0),(12376,'欧美色图','/oumeisetu/index.html','http://667jiu.com','https://www.y21j45k89b66.com/160C02/p03/%E6%A1%83%E6%A8%82%E6%96%AF%5B14P%5D/01.jpg','2023-03-06 22:14:03',1.2,3,1,'porn_sex',0),(12377,'动漫图片','/dongmantupian/index.html','http://667jiu.com','https://www.y21j45k89b66.com/160C08/p04/%E6%9C%89%E4%B8%AA%E8%BF%99%E6%A0%B7%E7%9A%84%E8%80%81%E5%B8%88%E8%B0%81%E8%BF%98%E5%AD%A6%E4%B9%A0%5B19P%5D/01.jpg','2023-03-06 22:14:03',1.2,3,1,'porn_sex',0),(12378,'美腿丝袜','/meituisiwa/index.html','http://667jiu.com','https://www.y21j45k89b66.com/160C08/p05/%E6%88%91%E7%9A%84%E8%95%BE%E7%B5%B2%E5%A5%B3%E4%BB%86%E5%92%8C%E6%A3%AE%E6%9E%97%E5%A5%B3%E7%A5%9E2%5B14P%5D/01.jpg','2023-03-06 22:14:03',1.2,3,1,'porn_sex',0),(12379,'清纯唯美','/qingchunweimei/index.html','http://667jiu.com','https://www.y21j45k89b66.com/160C02/p06/Abigail%5B21P%5D/01.jpg','2023-03-06 22:14:03',1.2,3,1,'porn_sex',0),(12380,'熟女图区','/shunvtuqu/index.html','http://667jiu.com','https://www.y21j45k89b66.com/160C0E/p07/%E5%9B%9B%E5%8D%81%E8%B7%AF%E8%B1%8A%E4%B9%B3%E7%86%9F%E5%A5%B3%E3%81%A8%E3%81%8A%E8%A6%8B%E5%90%88%E3%81%84%E5%A4%A7%E4%B9%B1%E4%BA%A4%5B20P%5D/01.jpg','2023-03-06 22:14:03',1.2,3,1,'porn_sex',0),(12381,'另类图片','/lingleitupian/index.html','http://667jiu.com','https://www.y21j45k89b66.com/160C0B/p08/%5B%E7%B4%97%E4%B9%8B%E6%AD%90%E7%BE%8E%5D%E7%9C%BC%E7%9D%9B%E5%86%B0%E6%B7%87%E6%B7%8B%5B18P%5D/01.jpg','2023-03-06 22:14:03',1.2,3,1,'porn_sex',0),(13284,'女优画报','女优画报','http://www.nyg6.com','https://mnysm8.com/uploadfile/image/20220331/027421328.jpg','2019-02-14 23:32:19',1.2,3,1,'porn_sex',0),(13291,'女优画报','/25/','https://mnysm8.com','https://mnysm8.com/uploadfile/image/20220331/027421328.jpg','2023-03-05 13:52:06',1.2,3,1,'porn_sex',0),(13292,'女优画报','/22/','https://mnysm8.com','https://mnysm8.com/uploadfile/image/20220331/027421328.jpg','2023-03-05 14:02:58',1.2,3,1,'porn_sex',0),(13293,'女优画报','/24/','https://mnysm8.com','https://mnysm8.com/uploadfile/image/20220331/027421328.jpg','2023-03-05 14:02:58',1.2,3,1,'porn_sex',0);
/*!40000 ALTER TABLE `imgchannel` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-08 13:32:16
