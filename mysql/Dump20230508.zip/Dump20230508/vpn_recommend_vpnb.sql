-- MySQL dump 10.13  Distrib 8.0.25, for macos11 (x86_64)
--
-- Host: 140.99.221.95    Database: vpn
-- ------------------------------------------------------
-- Server version	5.6.40-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `recommend_vpnb`
--

DROP TABLE IF EXISTS `recommend_vpnb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recommend_vpnb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(45) COLLATE utf8_bin NOT NULL,
  `actionUrl` varchar(120) COLLATE utf8_bin NOT NULL,
  `img` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `desc` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `enable` int(11) DEFAULT '1',
  `color` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `rate` float DEFAULT '1',
  `imgPath` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `param` varchar(60) COLLATE utf8_bin DEFAULT NULL,
  `type` int(11) DEFAULT '0',
  `adsShow` int(11) DEFAULT '0',
  `adsPopShow` int(11) DEFAULT '0',
  `showType` int(11) DEFAULT '0',
  `newShow` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recommend_vpnb`
--

LOCK TABLES `recommend_vpnb` WRITE;
/*!40000 ALTER TABLE `recommend_vpnb` DISABLE KEYS */;
INSERT INTO `recommend_vpnb` VALUES (1,'Google','https://www.google.com/','google.jpg',NULL,1,1,'#dedfe4',0.6,'http://img.sspacee.com/file/recommend/',NULL,0,1,NULL,0,0),(2,'YouTube','https://m.youtube.com/','youtube.jpg',NULL,1,1,'#cfcfcf',0.75,'http://img.sspacee.com/file/recommend/',NULL,0,1,NULL,0,0),(3,'Wikipedia','https://en.wikipedia.org/wiki/Main_Page','wiki.jpg',NULL,1,1,'#f2f2f2',1,'http://img.sspacee.com/file/recommend/',NULL,0,0,NULL,0,0),(4,'Facebook','https://m.facebook.com/','facebook2.jpg',NULL,1,1,'#355393',1,'http://img.sspacee.com/file/recommend/',NULL,0,0,NULL,0,0),(5,'Twitter','https://mobile.twitter.com/','twtter.jpg',NULL,1,1,'#2380c5',1,'http://img.sspacee.com/file/recommend/',NULL,0,0,NULL,0,0),(7,'Tumblr','browser://config?url=http%3a%2f%2fwww.tumblr.com','tumblr.jpg',NULL,1,0,'#33536c',0.82,'http://img.sspacee.com/file/recommend/',NULL,0,0,NULL,0,0),(11,'Amazon','http://www.amazon.com/','amazon.jpg',NULL,1,1,'#1165a5',1,'http://img.sspacee.com/file/recommend/',NULL,0,0,NULL,0,0),(12,'HULU','http://www.hulu.com/','hulu.jpg',NULL,1,1,'#86b1ed',0.53,'http://img.sspacee.com/file/recommend/',NULL,0,0,NULL,0,0),(32,'instagram','browser://config?url=http%3a%2f%2fwww.instagram.com/','instagram.jpg',NULL,1,1,'#d4c8b8',0.67,'http://img.sspacee.com/file/recommend/',NULL,0,0,NULL,0,0),(34,'wikileaks','https://wikileaks.org/','wikileaks.jpg',NULL,1,1,'#424764',0.667,'http://img.sspacee.com/file/recommend/',NULL,0,0,NULL,0,0),(35,'VPN线路说明','browser://config?url=http%3a%2f%2fsspacee.com',NULL,NULL,-1,1,'#f70009',1,NULL,NULL,0,0,0,0,1),(36,'Netflix','https://www.netflix.com/',NULL,NULL,-1,1,'#887267',1,NULL,NULL,0,0,0,0,1),(37,'积分说明','browser://config?url=http%3a%2f%2ffile.sspacee.com%2ffile%2fhtml%2fabout.html%3f344',NULL,NULL,-1,0,NULL,1,NULL,NULL,0,0,0,0,0);
/*!40000 ALTER TABLE `recommend_vpnb` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-08 13:46:45
