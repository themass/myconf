-- MySQL dump 10.13  Distrib 8.0.25, for macos11 (x86_64)
--
-- Host: 140.99.221.95    Database: sspanel
-- ------------------------------------------------------
-- Server version	5.6.40-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ss_node`
--

DROP TABLE IF EXISTS `ss_node`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ss_node` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `server` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `method` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'rc4-md5',
  `protocol` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'origin',
  `protocol_param` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `obfs` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'plain',
  `obfs_param` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `traffic_rate` double(8,2) NOT NULL DEFAULT '1.00',
  `info` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `offset` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `ss_enable` int(11) NOT NULL DEFAULT '1',
  `v2ray_enable` int(11) NOT NULL DEFAULT '0',
  `https_enable` int(11) NOT NULL DEFAULT '0',
  `v2ray_port` int(11) NOT NULL DEFAULT '8100',
  `v2ray_protocol` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'tcp',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ss_node`
--

LOCK TABLES `ss_node` WRITE;
/*!40000 ALTER TABLE `ss_node` DISABLE KEYS */;
INSERT INTO `ss_node` VALUES (2,'美国',1,'104.160.175.162','rc4-md5','origin',NULL,'plain',NULL,1.00,'','1',1,0,1,0,0,8100,'tcp'),(3,'香港',1,'185.133.193.132','rc4-md5','origin',NULL,'plain',NULL,1.00,'','1',1,0,1,0,0,8100,'tcp'),(4,'hiformance-us-107.174.83.194',1,'107.174.83.194','rc4-md5','origin',NULL,'plain',NULL,1.00,'','1',1,0,1,0,0,8100,'tcp'),(5,'ali-sg-47.88.172.196',1,'47.88.172.196','rc4-md5','origin',NULL,'plain',NULL,1.00,'','1',1,0,1,0,0,8100,'tcp'),(6,'日本',1,'103.56.55.37','rc4-md5','origin',NULL,'plain',NULL,1.00,'','1',1,0,1,0,0,8100,'tcp'),(7,'香港',1,'47.52.193.243','rc4-md5','origin',NULL,'plain',NULL,1.00,'','1',1,0,1,0,0,8100,'tcp'),(8,'我的google',1,'104.129.20.132','rc4-md5','origin',NULL,'plain',NULL,1.00,'','1',1,0,1,0,0,8100,'tcp'),(9,'我的google',1,'103.94.185.67','rc4-md5','origin',NULL,'plain',NULL,1.00,'','1',1,0,1,0,0,8100,'tcp'),(10,'google-台湾',1,'104.199.135.25','rc4-md5','origin',NULL,'plain',NULL,1.00,'','1',1,0,1,0,0,8100,'tcp'),(11,'菲律宾',1,'116.93.124.215','rc4-md5','origin',NULL,'plain',NULL,1.00,'','1',1,0,1,0,0,8100,'tcp');
/*!40000 ALTER TABLE `ss_node` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-08 13:49:35
